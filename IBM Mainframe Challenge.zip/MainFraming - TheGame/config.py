zos_id = 'z58586'
zos_id_cap = 'Z58586'
uss_backup_folder = '/z/z58586/backups'
local_restore_folder = 'backups_restore'
